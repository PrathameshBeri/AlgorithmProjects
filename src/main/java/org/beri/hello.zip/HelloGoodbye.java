

public class HelloGoodbye {
    public static void main(String[] names) {



        System.out.println("Hello " + names[0] + " and " + names[1] + ".");
        System.out.printf("Goodbye %s and %s.", names[1], names[0]);
    }
}
